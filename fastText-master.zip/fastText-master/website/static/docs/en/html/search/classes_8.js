var searchData=
[
  ['vector',['Vector',['../classfasttext_1_1Vector.html',1,'fasttext']]]
];
